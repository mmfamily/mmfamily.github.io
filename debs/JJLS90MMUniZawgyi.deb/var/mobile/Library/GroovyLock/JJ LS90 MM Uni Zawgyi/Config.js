var Unicode = false;
var Clock = "12h"; // Do not Modify.
var lang = "mm"; // choose between "sp", "en", "de" or "fr"
