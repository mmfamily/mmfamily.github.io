/*
Configuration here!
Code by Dacal -- Modified by Schnedi  // D0 NOT REMOVE THIS LINE //
*/
var Unicode= false;
var Clock = "12h";		// Do not Modify.
var lang = "mm";		    // choose between "sp", "en", "de" or "fr"