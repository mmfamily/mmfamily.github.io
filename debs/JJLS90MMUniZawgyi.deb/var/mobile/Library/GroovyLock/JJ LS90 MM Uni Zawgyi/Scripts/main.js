window.addEventListener("load", function() { 
	document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

switch (lang) {
case "fr":
	var days = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
	var months=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];
break;


case "mm":
var date = ["","၁","၂","၃","၄","၅","၆","၇","၈","၉","၁၀","၁၁","၁၂","၁၃","၁၄","၁၅","၁၆","၁၇","၁၈","၁၉","၂၀", "၂၁","၂၂","၂၃","၂၄","၂၅","၂၆", "၂၇","၂၈","၂၉", "၃၀", "၃၁"];

if (Unicode){
var days = ["တနင်္ဂနွေနေ့","တနင်္လာနေ့","အင်္ဂါနေ့","ဗုဒ္ဓဟူးနေ့","ကြာသပတေးနေ့","သောကြာနေ့","စနေနေ့"];
			var months = ["ဇန်နဝါရီ","ဖေဖေါ်ဝါရီ","မတ်","ဧပြီ","မေ","ဇွန်","ဇူလိုင်","ဩဂုတ်","စက်တင်ဘာ","အောက်တိုဘာ","နိုဝင်ဘာ","ဒီဇင်ဘာ"];
						
						var yat="ရက်";
}
						else{
	var days = ["တနဂၤေႏြေန႔","တနလၤာေန႔","အဂၤါေန႔","ဗုဒၶဟူးေန႔","ၾကာသပေတးေန႔","ေသာၾကာေန႔","စေနေန႔"];
			var months = ["ဇန္နဝါရီ","ေဖေဖၚဝါရီ","မတ္","ဧျပီ","ေမ","ဇြန္","ဇူလိုင္္","ဩဂုတ္္","စက္တင္ဘာ","ေအာက္တိုဘာ","နိုဝင္ဘာ","ဒီဇင္ဘာ"];
						var yat="ရက္";
}
break;
case "de":
	var days = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
	var months=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];		
break;
case "sp":
	var days = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];
	var months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
break;
default: 
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
break;
}

function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes();
var currentMinutes1 = currentTime.getMinutes();
var currentMinutesunit = currentTime.getMinutes ( );
var currentSeconds = currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();

//timeOfDay = ( currentHours < 12 ) ? "am" : "pm";
if (Unicode){
if ( currentHours< 1) {timeOfDay ="ညသန်းခေါင်ယံ";}
      else if (currentHours <5) {timeOfDay ="နံနက်";}
      else if (currentHours <8) {timeOfDay ="နံနက်ခင်း";}
      else if (currentHours <12) {timeOfDay="နံနက်";}
      else if (currentHours <14) {timeOfDay="နေ့လည်";}
      else if (currentHours <15) {timeOfDay ="နေ့လည်ခင်း";}
      else if (currentHours <16) {timeOfDay ="ညနေ";}
      else if (currentHours <18) {timeOfDay ="ညနေခင်း";}
      else {timeOfDay = "ည";}
}
else{
	if ( currentHours< 1) {timeOfDay ="ညသန္းေခါင္ယံ";}
      else if (currentHours <5) {timeOfDay ="နံနက္";}
      else if (currentHours <8) {timeOfDay ="နံနက္ခင္း";}
      else if (currentHours <12) {timeOfDay="နံနက္";}
      else if (currentHours <14) {timeOfDay="ေန႔လည္";}
      else if (currentHours <15) {timeOfDay ="ေန႔လည္ခင္း";}
      else if (currentHours <16) {timeOfDay ="ညေန";}
      else if (currentHours <18) {timeOfDay ="ညေနခင္း";}
      else {timeOfDay = "ည";}
	
	}

if (lang == "mm" & Unicode){
	
       
       if (currentYear==2015){currentYear="၂၀၁၅";}
	else if (currentYear==2016){currentYear="၂၀၁၆";}
	else if (currentYear==2017){currentYear="၂၀၁၇";}
	else if (currentYear==2018){currentYear="၂၀၁၈";}
	else if (currentYear==2019){currentYear="၂၀၁၉";}
	else if (currentYear==2020){currentYear="၂၀၂၀";}
	else {currentYear=currentYear;}
     
   var currentHours_name_array = new Array ("ဆယ့်နှစ်နာရီ", "တစ်နာရီ", "နှစ်နာရီ", "သုံးနာရီ", "လေးနာရီ", "ငါးနာရီ",  "ခြောက်နာရီ" ,  "ခုနှစ်နာရီ", "ရှစ်နာရီ", "ကိုးနာရီ", "ဆယ်နာရီ", "ဆယ့်တစ်နာရီ", "ဆယ့်နှစ်နာရီ", "တစ်နာရီ", "နှစ်နာရီ", "သုံးနာရီ", "လေးနာရီ", "ငါးနာရီ",	"ခြောက်နာရီ" ,	"ခုနှစ်နာရီ", "ရှစ်နာရီ", "ကိုးနာရီ", "ဆယ်နာရီ", "ဆယ့်တစ်နာရီ", "ဆယ့်နှစ်နာရီ")

   var currentMinutes_name_array = new Array ("", "", "", "", "", "", "", "", "", "", "ဆယ်မိနစ်", "ဆယ့်တစ်မိနစ်", "ဆယ့်နှစ်မိနစ်", "ဆယ့်သုံးမိနစ်", "ဆယ့်လေးမိနစ်", "ဆယ့်ငါးမိနစ်", "ဆယ့်ခြောက်မိနစ်","ဆယ့်ခုနှစ်မိနစ်" ,"ဆယ့်ရှစ်မိနစ်","ဆယ့်ကိုးမိနစ်", "နှစ်ဆယ်မိနစ်", "နှစ်ဆယ့်","နှစ်ဆယ့်","နှစ်ဆယ့်","နှစ်ဆယ့်","နှစ်ဆယ့်","နှစ်ဆယ့်","နှစ်ဆယ့်","နှစ်ဆယ့်","နှစ်ဆယ့်","ခွဲ","သုံးဆယ့်","သုံးဆယ့်","သုံးဆယ့်","သုံးဆယ့်","သုံးဆယ့်","သုံးဆယ့်","သုံးဆယ့်","သုံးဆယ့်","သုံးဆယ့်","လေးဆယ်မိနစ်","လေးဆယ့်","လေးဆယ့်","လေးဆယ့်","လေးဆယ့်","လေးဆယ့်","လေးဆယ့်","လေးဆယ့်","လေးဆယ့်","လေးဆယ့်","ငါးဆယ်မိနစ်","ငါးဆယ့်","ငါးဆယ့်","ငါးဆယ့်","ငါးဆယ့်","ငါးဆယ့်","ငါးဆယ့်","ငါးဆယ့်","ငါးဆယ့်","ငါးဆယ့်", "")

   var currentMinutesunit_name_array = new Array ("", "တစ်မိနစ်", "နှစ်မိနစ်", "သုံးမိနစ်", "လေးမိနစ်", "ငါးမိနစ်",  "ခြောက်မိနစ်" ,  "ခုနှစ်မိနစ်", "ရှစ်မိနစ်", "ကိုးမိနစ်", "", "", "", "", "", "", "", "", "", "", "", "တစ်မိနစ်", "နှစ်မိနစ်", "သုံးမိနစ်", "လေးမိနစ်", "ငါးမိနစ်",  "ခြောက်မိနစ်" ,  "ခုနှစ်မိနစ်", "ရှစ်မိနစ်", "ကိုးမိနစ်", "", "တစ်မိနစ်", "နှစ်မိနစ်", "သုံးမိနစ်", "လေးမိနစ်", "ငါးမိနစ်",  "ခြောက်မိနစ်" ,	"ခုနှစ်မိနစ်", "ရှစ်မိနစ်", "ကိုးမိနစ်", "","တစ်မိနစ်", "နှစ်မိနစ်", "သုံးမိနစ်", "လေးမိနစ်", "ငါးမိနစ်",  "ခြောက်မိနစ်" ,  "ခုနှစ်မိနစ်", "ရှစ်မိနစ်", "ကိုးမိနစ်", "", "တစ်မိနစ်", "နှစ်မိနစ်", "သုံးမိနစ်", "လေးမိနစ်", "ငါးမိနစ်",	"ခြောက်မိနစ်" ,  "ခုနှစ်မိနစ်", "ရှစ်မိနစ်", "ကိုးမိနစ်", "")
}

if (lang == "mm" & !Unicode){
	
	if (currentYear==2015){currentYear="၂၀၁၅";}
	else if (currentYear==2016){currentYear="၂၀၁၆";}
	else if (currentYear==2017){currentYear="၂၀၁၇";}
	else if (currentYear==2018){currentYear="၂၀၁၈";}
	else if (currentYear==2019){currentYear="၂၀၁၉";}
	else if (currentYear==2020){currentYear="၂၀၂၀";}
	else {currentYear=currentYear;}
	
   var currentHours_name_array = new Array ("ဆယ့္ႏွစ္နာရီ", "တစ္နာရီ", "ႏွစ္နာရီ", "သုံးနာရီ", "ေလးနာရီ", "ငါးနာရီ",  "ေျခာက္နာရီ" ,  "ခုႏွစ္နာရီ", "ရွစ္နာရီ", "ကိုးနာရီ", "ဆယ္နာရီ", "ဆယ့္တစ္နာရီ", "ဆယ့္ႏွစ္နာရီ", "တစ္နာရီ", "ႏွစ္နာရီ", "သုံးနာရီ", "ေလးနာရီ", "ငါးနာရီ",	"ေျခာက္နာရီ" ,	"ခုႏွစ္နာရီ", "ရွစ္နာရီ", "ကိုးနာရီ", "ဆယ္နာရီ", "ဆယ့္တစ္နာရီ", "ဆယ့္ႏွစ္နာရီ")

   var currentMinutes_name_array = new Array ("", "", "", "", "", "", "", "", "", "", "ဆယ္မိနစ္", "ဆယ့္တစ္မိနစ္", "ဆယ့္ႏွစ္မိနစ္", "ဆယ့္သုံးမိနစ္", "ဆယ့္ေလးမိနစ္", "ဆယ့္ငါးမိနစ္", "ဆယ့္ေျခာက္မိနစ္","ဆယ့္ခုႏွစ္မိနစ္" ,"ဆယ့္ရွစ္မိနစ္","ဆယ့္ကိုးမိနစ္", "ႏွစ္ဆယ္မိနစ္", "ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ႏွစ္ဆယ့္","ခြဲ","သုံးဆယ့္","သုံးဆယ့္","သုံးဆယ့္","သုံးဆယ့္","သုံးဆယ့္","သုံးဆယ့္","သုံးဆယ့္","သုံးဆယ့္","သုံးဆယ့္","ေလးဆယ္မိနစ္","ေလးဆယ့္","ေလးဆယ့္","ေလးဆယ့္","ေလးဆယ့္","ေလးဆယ့္","ေလးဆယ့္","ေလးဆယ့္","ေလးဆယ့္","ေလးဆယ့္","ငါးဆယ္မိနစ္","ငါးဆယ့္","ငါးဆယ့္","ငါးဆယ့္","ငါးဆယ့္","ငါးဆယ့္","ငါးဆယ့္","ငါးဆယ့္","ငါးဆယ့္","ငါးဆယ့္", "")

   var currentMinutesunit_name_array = new Array ("", "တစ္မိနစ္", "ႏွစ္မိနစ္", "သုံးမိနစ္", "ေလးမိနစ္", "ငါးမိနစ္",  "ေျခာက္မိနစ္" ,  "ခုႏွစ္မိနစ္", "ရွစ္မိနစ္", "ကိုးမိနစ္", "", "", "", "", "", "", "", "", "", "", "", "တစ္မိနစ္", "ႏွစ္မိနစ္", "သုံးမိနစ္", "ေလးမိနစ္", "ငါးမိနစ္",  "ေျခာက္မိနစ္" ,  "ခုႏွစ္မိနစ္", "ရွစ္မိနစ္", "ကိုးမိနစ္", "", "တစ္မိနစ္", "ႏွစ္မိနစ္", "သုံးမိနစ္", "ေလးမိနစ္", "ငါးမိနစ္",  "ေျခာက္မိနစ္" ,	"ခုႏွစ္မိနစ္", "ရွစ္မိနစ္", "ကိုးမိနစ္", "","တစ္မိနစ္", "ႏွစ္မိနစ္", "သုံးမိနစ္", "ေလးမိနစ္", "ငါးမိနစ္",  "ေျခာက္မိနစ္" ,  "ခုႏွစ္မိနစ္", "ရွစ္မိနစ္", "ကိုးမိနစ္", "", "တစ္မိနစ္", "ႏွစ္မိနစ္", "သုံးမိနစ္", "ေလးမိနစ္", "ငါးမိနစ္",	"ေျခာက္မိနစ္" ,  "ခုႏွစ္မိနစ္", "ရွစ္မိနစ္", "ကိုးမိနစ္", "")
}

if (lang == "en"){
   var currentHours_name_array = new Array ("Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve")
   var currentMinutes_name_array = new Array ("O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "")
   var currentMinutesunit_name_array = new Array ("clock", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "")
}

if (lang == "fr"){
   var currentHours_name_array = new Array ("minuit", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "midi", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "minuit")
   var currentMinutes_name_array = new Array ("et", "et", "et", "et", "et", "et", "et", "et", "et", "et", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "")
   var currentMinutesunit_name_array = new Array ("heure", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "")
}
if (lang == "de"){
   var currentHours_name_array = new Array ("null", "ein", "zwei", "drei", "vier", "fünf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwölf", "dreizehn", "vierzehn", "fünfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn", "zwanzig", "einundzwanzig", "zweiundzwanzig", "dreiundzwanzig", "null")
   var currentMinutes_name_array = new Array ("uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr")
   var currentMinutesunit_name_array = new Array ("", "eins", "zwei", "drei", "vier", "fünf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwölf", "dreizehn", "vierzehn", "fünfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn", "zwanzig", "einundzwanzig", "zweiundzwanzig", "dreiundzwanzig", "vierundzwanzig", "fünfundzwanzig", "sechsundzwanzig", "siebenundzwanzig", "achtundzwanzig","neunundzwanzig", "dreißig", "einunddreißig", "zweiunddreißig", "dreiunddreißig", "vierunddreißig", "fünfunddreißig", "sechsunddreißig", "siebenunddreißig", "achtunddreißig", "neununddreißig", "vierzig", "einundvierzig", "zweiundvierzig", "dreiundvierzig", "vierundvierzig", "fünfundvierzig", "sechsundvierzig", "siebenundvierzig", "achtundvierzig", "neunundvierzig", "fünfzig", "einundfünfzig", "zweiundfünfzig", "dreiundfünfzig", "vierundfünfzig", "fünfundfünfzig", "sechsundfünfzig", "siebenundfünfzig", "achtundfünfzig", "neunundfünfzig" , "")	
}
if (lang == "sp"){
   var currentHours_name_array = new Array ("doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce")
   var currentMinutes_name_array = new Array ("en punto", "y", "y", "y", "y", "y", "y", "y", "y", "y", "y diez", "y once", "y doce", "y trece", "y catorce", "y quince", "y dieciseis", "y diecisiete", "y dieciocho", "y diecinueve", "y veinte", "veinti", "veinti", "veinti", "veinti", "veinti", "veinti", "veinti", "veinti", "veinti", "y treinta", "treinta", "treinta", "treinta", "treinta", "treinta", "treinta", "treinta", "treinta", "treinta", "cuarenta", "y cuarenta", "cuarenta", "cuarenta", "cuarenta", "cuarenta", "cuarenta", "cuarenta", "cuarenta", "cuarenta", "y cincuenta", "cincuenta", "cincuenta", "cincuenta", "cincuenta", "cincuenta", "cincuenta", "cincuenta", "cincuenta", "cincuenta", "")
   var currentMinutesunit_name_array = new Array ("", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", " ", "y uno", "y dos", "y tres", "y cuatro", "y cinco", "y seis", "y siete", "y ocho", "y nueve", " ", "y uno", "y dos", "y tres", "y cuatro", "y cinco", "y seis", "y siete", "y ocho", "y nueve", " ", "y uno", "y dos", "y tres", "y cuatro", "y cinco", "y seis", "y siete", "y ocho", "y nueve", "")
}

if (Clock == "24h") {
	currentHours = ( currentHours < 10 ? "" : "" ) + currentHours;
	currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	currentTimeString1 = currentHours + ":" + currentMinutes1;
	document.getElementById("ampm").innerHTML = timeOfDay;
}
if (Clock == "12h") {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	currentTimeString1 = currentHours + ":" + currentMinutes1;
	document.getElementById("ampm").innerHTML = timeOfDay;
}

document.getElementById("hour").innerHTML = currentHours_name_array[currentHours];
document.getElementById("minute").innerHTML = currentMinutes_name_array[currentMinutes];
document.getElementById("minutesunit").innerHTML = currentMinutesunit_name_array[currentMinutesunit];

document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("date").innerHTML = date[currentDate];
document.getElementById("month").innerHTML = months[currentTime.getMonth()];
document.getElementById("year").innerHTML = currentYear;
document.getElementById("yat").innerHTML = yat;

}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}