var TwentyFourHour = false; // 12 of 24 hour time
var ampm = true;
var ClockHeight = 100;
var Language = "mm"; // Only English [en] and Myanmar [mm] Portuguese [pg] French [fr] Spanish [sp]
