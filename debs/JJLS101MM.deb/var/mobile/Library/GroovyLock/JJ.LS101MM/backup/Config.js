/*
Configuration here !
Code by Dacal -- Modified by Schnedi  // D0 NOT REMOVE THIS LINE //
*/
var Clock = "12h"; // choose between "12h" or "24h".
var lang = "mm"; // choose between "mm","sp", "en", "de", or "fr".
var hourcolor = "orange";
var minutecolor = "yellow";
var TimeWordscolor = "yellow";
var Datecolor = "red";
var Weekdaycolor = "blue";
var Monthcolor = "green";
var Yearcolor = "white";